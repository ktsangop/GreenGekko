# CCXT PHP Examples

To run PHP examples from any folder type in console:

```shell
php -f path/to/example.php # substitute for actual filename here
```