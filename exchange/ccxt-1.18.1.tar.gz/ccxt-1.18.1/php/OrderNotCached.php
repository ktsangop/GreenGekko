<?php

namespace ccxt;

class OrderNotCached extends InvalidOrder {

}