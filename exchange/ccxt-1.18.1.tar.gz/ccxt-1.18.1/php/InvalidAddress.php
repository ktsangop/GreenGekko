<?php

namespace ccxt;

use Exception;

class InvalidAddress extends ExchangeError {

}
