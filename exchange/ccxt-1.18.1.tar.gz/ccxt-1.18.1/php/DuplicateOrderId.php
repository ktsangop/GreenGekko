<?php

namespace ccxt;

class DuplicateOrderId extends InvalidOrder {

}
