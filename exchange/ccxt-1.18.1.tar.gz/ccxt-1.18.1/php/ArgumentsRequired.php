<?php

namespace ccxt;

use Exception;

class ArgumentsRequired extends ExchangeError {

}
