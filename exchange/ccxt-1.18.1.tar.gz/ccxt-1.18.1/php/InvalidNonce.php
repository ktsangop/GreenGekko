<?php

namespace ccxt;

class InvalidNonce extends NetworkError {

}
