<?php

namespace ccxt;

use Exception;

class BaseError extends Exception {

}